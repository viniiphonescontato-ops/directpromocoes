# Direct Promoções Dashboard

Aplicativo web estático em HTML, CSS e JavaScript puro para operação da Direct Promoções.

## Como abrir

Abra `index.html` no navegador. O app continua funcionando localmente com `localStorage`.

## Visual e uso

- Tema glass com modo claro/escuro.
- Cards compactos com sombras, bordas arredondadas e animações no hover.
- Dashboard com KPIs, faturamento, diárias atendidas e gráficos de pizza/rosca.
- Abas funcionais para Diaristas, Demandas, Lojas & Redes, Financeiro e Configurações.
- Busca focada em Diaristas e Demandas.
- Cadastros, edição, exclusão e escala básica de diaristas em demandas.

## Preparado para Supabase

Arquivos adicionados:

- `supabase-client.js`: cliente opcional do Supabase.
- `backend.config.js`: configuração local do projeto Supabase.
- `backend.config.example.js`: exemplo de configuração.
- `supabase.schema.sql`: estrutura inicial das tabelas.
- `supabase.demand-period-migration.sql`: migracao para adicionar data final nas demandas existentes.
- `supabase.policies.sql`: políticas RLS para liberar leitura e escrita pela chave pública `anon`.
- `supabase.secure-auth-policies.sql`: políticas RLS recomendadas para liberar leitura e escrita somente para usuarios autenticados.

Para conectar:

1. Crie um projeto no Supabase.
2. Rode o conteúdo de `supabase.schema.sql` no SQL Editor.
3. Rode o conteúdo de `supabase.policies.sql` no SQL Editor.
4. Se o banco ja existir, rode tambem `supabase.demand-period-migration.sql`.
5. Copie a URL do projeto e a chave pública `anon`.
6. Preencha `backend.config.js`:

```js
window.DIRECT_BACKEND_CONFIG = {
  supabaseUrl: "https://SEU-PROJETO.supabase.co",
  supabaseAnonKey: "SUA_CHAVE_PUBLICA_ANON",
};
```

O app está em modo híbrido: abre com `localStorage`, carrega dados do Supabase quando disponível e sincroniza alterações de cadastros, demandas, lojas, setores e valores. Se uma tabela estiver vazia, o app envia a base local atual para iniciar o banco.

Se as demandas salvarem, mas a data final voltar igual a data inicial, rode `supabase.demand-period-migration.sql` no SQL Editor. Essa migration adiciona a coluna `end_date` usada para periodos com mais de um dia.

## Acesso administrativo

O sistema abre com login interno e sem opcao de criar conta.

- Login: `marcosvinidirect@gmail.com`
- Senha: definida no app apenas como hash SHA-256, nao em texto puro.

Para seguranca real no Supabase:

1. Crie um usuario em Authentication > Users com o email `marcosvinidirect@gmail.com` e a mesma senha administrativa.
2. Depois disso, rode `supabase.secure-auth-policies.sql` no SQL Editor.

Nao rode `supabase.secure-auth-policies.sql` antes de criar esse usuario, pois as tabelas deixam de aceitar escrita anonima e o app nao conseguira salvar no banco.

As políticas atuais liberam CRUD para a chave pública `anon`, adequado para um protótipo sem login. Para produção, o ideal é adicionar autenticação e restringir as políticas por usuário ou equipe.

## Preparado para Vercel

Arquivo adicionado:

- `vercel.json`
- `.vercelignore`
- `package.json`

Para publicar:

1. Suba a pasta para um repositório GitHub.
2. Importe o projeto na Vercel como projeto estático.
3. Mantenha `index.html` como entrada principal.
4. Se usar Supabase, garanta que `backend.config.js` esteja preenchido antes do deploy ou gere esse arquivo no processo de build.

Também é possível publicar pela CLI:

```bash
npm i -g vercel
vercel login
vercel --prod
```
